#!/usr/bin/env python3
import numpy as np
from math import pi
import rospy
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import roboticstoolbox as rtb